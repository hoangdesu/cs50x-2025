SELECT name --, tempo 
FROM songs
ORDER BY tempo;